import { useAuth } from "./useAuth";
import { logout } from "./logout";
import Subaa_Logo from "../assets/Subaa_Logo.png";
import { supabase } from './supabaseClient';
import { useEffect, useState } from "react";

const Navbar = () => {
    const { user, role, loading } = useAuth();
    const [fullName, setFullName] = useState("");
   useEffect(() => {
    const fetchProfile = async () => {
        if (!user) return;

        let tableName = "";

        if (role === "patient") {
            tableName = "patients";
        } else if (role === "professional") {
            tableName = "professionals";
        } else {
            return; // admin or other roles
        }

        const { data, error } = await supabase
            .from(tableName)
            .select("full_name")
            .eq("id", user.id)
            .single();

        if (error) {
            console.error("Error fetching profile:", error);
            return;
        }

        if (data) {
            setFullName(data.full_name);
        }
    };

    fetchProfile();
}, [user, role]);

    // Function to get initials
    const getInitials = (fullName, fallback) => {
        const name = fullName?.trim() || fallback?.trim() || "?";

        const words = name.split(/\s+/).filter(Boolean);

        if (words.length >= 2) {
            return (
                words[0].charAt(0) +
                words[words.length - 1].charAt(0)
            ).toUpperCase();
        }

        return words[0].slice(0, 2).toUpperCase();

    };
    return (

        <nav className="navbar navbar-expand-lg navbar-light bg-light pt-0 pb-0 nav-style">

            <div className="container-fluid">
                <a href="/home" target="_blank" className="navbar-brand mr-2">
                    <img src={Subaa_Logo} alt="Logo" className="logo" style={{ height: "6rem", padding: "0" }} />
                </a>
                <div className="text-start">
                    <a className="navbar-brand fw-bold text-blue fs-25" href="/home">Subaa Care</a>
                    <p className="fs-14 text-blue mb-0 mt-0 text-blue">we care of those who you care</p>
                </div>

                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav ms-auto align-items-center" style={{ gap: "10px" }}>
                        {/* Always visible */}
                        <li className="nav-item">
                            <a className="nav-link" href="/home">Home</a>
                        </li>
                        {/* Always visible */}
                        <li className="nav-item">
                            <a className="nav-link" href="/aboutus">About Us</a>
                        </li>
                        {/* NOT LOGGED IN */}
                        {!user && (
                            <>
                                <li className="nav-item">
                                    <a className="nav-link" href="/register">Register</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/login">Sign In</a>
                                </li>
                            </>
                        )}

                        {/* Logged-in role-based links */}
                        {user && role === "patient" && (
                            <>
                                <li className="nav-item">
                                    <a className="nav-link" href="/patient">Dashboard</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link" href="/myappointments">My Appointments</a> </li>
                                <li>
                                    <a className="nav-link" href="/transactions"> Transaction History</a></li>
                            </>
                        )}
                        {user && role === "professional" && (
                            <li className="nav-item">
                                <a className="nav-link" href="/professionaldashboard">Dashboard</a>
                            </li>
                        )}
                        {user && role === "admin" && (
                            <li className="nav-item">
                                <a className="nav-link" href="/admin">Admin Panel</a>
                            </li>
                        )}

                        {/* Avatar Dropdown */}
                        {user && (
                            <li className="nav-item dropdown">
                                <a
                                    className="nav-link dropdown-toggle d-flex align-items-center justify-content-center"
                                    href="#!"
                                    id="navbarDropdown"
                                    role="button"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                    style={{
                                        width: "45px",
                                        height: "45px",
                                        borderRadius: "50%",
                                        backgroundColor: "var(--bs-gray-200)",
                                        color: "#fff",
                                        fontWeight: "bold",
                                        fontSize: "1rem",
                                        textAlign: "center",
                                        lineHeight: "30px",
                                        cursor: "pointer",
                                        overflow: "hidden",
                                    }}
                                >
                                    {user.avatar ? (
                                        <img
                                            src={user.avatar}
                                            alt="avatar"
                                            className="rounded-circle"
                                            width="40"
                                            height="40"
                                        />
                                    ) : (
                                        getInitials(fullName, user.email || role)
                                    )}


                                </a>

                                <ul className="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    {user && role === "professional" && (
                                        <><li><a className="dropdown-item" href="/professional">My Profile</a></li>
                                            <li><hr className="dropdown-divider" /></li></>)}
                                    {user && role === "patient" && (
                                        <><li><a className="dropdown-item" href="/patientprofile">My Profile</a></li>

                                        </>)
                                    }

                                    <li>
                                        <button className="dropdown-item text-danger" onClick={logout}>
                                            Logout
                                        </button>
                                    </li>
                                </ul>
                            </li>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;
